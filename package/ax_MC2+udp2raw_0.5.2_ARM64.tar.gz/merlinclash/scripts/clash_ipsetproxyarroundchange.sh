#!/bin/sh

export KSROOT=/koolshare
source $KSROOT/scripts/base.sh
eval $(dbus export merlinclash_)
alias echo_date='echo 【$(date +%Y年%m月%d日\ %X)】:'
LOG_FILE=/tmp/upload/merlinclash_log.txt

rm -rf /tmp/upload/clash_ipsetproxyarround.log
rm -rf /tmp/upload/clash_ipsetproxyarround.txt
b(){
	if [ -f "/bin/base64" ]; then #HND是这个
		base=base64
		echo $base
	elif [ -f "/koolshare/bin/base64_decode" ]; then #HND有这个
		base=base64_decode
		echo $base
	elif [ -f "/koolshare/bin/base64" ]; then #网件R7K是这个
		base=base64
		echo $base
	elif [ -f "/sbin/base64" ]; then
		base=base64
		echo $base
	else
		echo_date "【错误】固件缺少base64decode文件，无法正常订阅，直接退出" >> $LOG_FILE
		echo_date "解决办法请查看MerlinClash Wiki" >> $LOG_FILE
		echo BBABBBBC >> $LOG_FILE
		exit 1
	fi
}
detect_domain() {
	domain1=$(echo $1 | grep -E "^https://|^http://")
	domain2=$(echo $1 | grep -E "\.")
	if [ -n "$domain1" ] || [ -z "$domain2" ]; then
		return 1
	else
		return 0
	fi
}
detect_ip() {
    IPADDR=$1
    # IPv4地址 + 可选掩码 /0-32
    regex_v4="^((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])(\/([0-9]|[1-2][0-9]|3[0-2]))?$"

    # 简化版IPv6地址 + 可选掩码 /0-128
    regex_v6="^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(::([0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{1,4}))(/([0-9]|[1-9][0-9]|1[01][0-9]|12[0-8]))?$"

    if echo "$IPADDR" | grep -Eq "$regex_v4"; then
        return 4
    elif echo "$IPADDR" | grep -Eq "$regex_v6"; then
        return 6
    else
        return 1
    fi
}

decode_url_link(){
	local link=$1
	local len=$(echo $link | wc -L)
	local mod4=$(($len%4))
	b64=$(b)
#	echo_date "b64=$b64" >> LOG_FILE
	if [ "$mod4" -gt "0" ]; then
		local var="===="
		local newlink=${link}${var:$mod4}
		echo -n "$newlink" | sed 's/-/+/g; s/_/\//g' | $b64 -d 2>/dev/null
	else
		echo -n "$link" | sed 's/-/+/g; s/_/\//g' | $b64 -d 2>/dev/null
	fi
}
get(){
	a=$(echo $(dbus get $1))
	a=$(echo $(dbus get $1))
	echo $a
}
yamlname=$(get merlinclash_yamlsel)
yamlpath=/koolshare/merlinclash/yaml_use/$yamlname.yaml
dnslistenport=$(cat $yamlpath | awk -F: '/listen/{print $3}' | xargs echo -n)
restart_dnsmasq() {
    # Restart dnsmasq
	echo_date "重启 dnsmasq..." >> $LOG_FILE
    service restart_dnsmasq >/dev/null 2>&1
}
apply_dnsmasq(){
	sed -i '/^ *$/d' /koolshare/merlinclash/yaml_basic/$1.yaml
	case $1 in
	
	ipsetproxyarround)
		ipset -F ipset_proxyarround >/dev/null 2>&1
		if [ -s "/koolshare/merlinclash/yaml_basic/ipsetproxyarround.yaml" ]; then
			if [ "$2" != "ip" ]; then
				echo_date "创建强制绕行Clash的ipset规则集" > $LOG_FILE
			fi
			rm -rf /tmp/ipset_proxyarround.list
			cp -rf /koolshare/merlinclash/yaml_basic/ipsetproxyarround.yaml /tmp/ipset_proxyarround.list 2>/dev/null
			rm -rf /tmp/clash_ipsetproxyarround_tmp.txt
			rm -rf /tmp/clash_ipsetproxyarround_tmp2.txt
			rm -rf /koolshare/merlinclash/conf/ipsetproxyarround.conf
			
			lines=$(cat /tmp/ipset_proxyarround.list | awk '{print $0}')
			for line in $lines
			do
				#先检测是否为IP格式
				detect_ip ${line}
				a=$?
				if [ "$a" == "4" ]; then
					echo_date "${line}为合法IPv4格式，进行处理" >> $LOG_FILE
					ipset -! add ipset_proxyarround ${line} >/dev/null 2>&1
				elif [ "$a" == "6" ]; then
					echo_date "${line}为合法IPv6格式，进行处理" >> $LOG_FILE
					ipset -! add ipset_proxyarround6 ${line} >/dev/null 2>&1
				else
					echo_date "${line}不为IP格式，检查是否为域名地址" >> $LOG_FILE
					detect_domain ${line}
					if [ "$?" == "0" ]; then
						echo_date "${line}为合法域名格式，进行处理" >> $LOG_FILE
						nslookup "${line}" > /tmp/clash_ipsetproxyarround_tmp.txt
						cat /tmp/clash_ipsetproxyarround_tmp.txt | grep -n "^Address" | awk -F " " '{print $3}' | grep -v "127.0.0.1" > /tmp/clash_ipsetproxyarround_tmp2.txt #域名解析结果可能含有V4跟V6地址。下一步再进行筛选
						lines=$(cat /tmp/clash_ipsetproxyarround_tmp2.txt | awk '{print $0}')
						for line2 in $lines
						do
							detect_ip ${line2}
							b=$?
							if [ "$b" == "4" ]; then
								#echo_date "为合法IPV4格式，进行处理" >> $LOG_FILE
								ipset -! add ipset_proxyarround ${line2} >/dev/null 2>&1
							elif [ "$b" == "6" ]; then
								#echo_date "为合法IPV6格式，进行处理" >> $LOG_FILE
								ipset -! add ipset_proxyarround6 ${line2} >/dev/null 2>&1
							fi
						done
						
						echo "$line" | sed "s/^/ipset=&\/./g" | sed "s/$/\/ipset_proxyarround,ipset_proxyarround6/g" >> /koolshare/merlinclash/conf/ipsetproxyarround.conf
					else
						echo_date "格式有误，略过" >> $LOG_FILE
					fi
				fi
			done
		else
			rm -rf /koolshare/merlinclash/conf/ipsetproxyarround.conf
		fi
		rm -rf /jffs/configs/dnsmasq.d/ipsetproxyarround.conf >/dev/null 2>&1
		if [ -f "/koolshare/merlinclash/conf/ipsetproxyarround.conf" ]; then
			ln -sf /koolshare/merlinclash/conf/ipsetproxyarround.conf /jffs/configs/dnsmasq.d/ipsetproxyarround.conf >/dev/null 2>&1
			echo_date "【完成】/koolshare/merlinclash/conf/ipsetproxyarround.conf文件创建成功！" >> $LOG_FILE
		fi
		if [ "$2" != "ip" ]; then
			restart_dnsmasq
		fi
		;;
	esac
}

case $2 in

ip)
	apply_dnsmasq "ipsetproxyarround" "ip"
	;;
esac
